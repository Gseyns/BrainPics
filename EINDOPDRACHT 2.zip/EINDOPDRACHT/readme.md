BrainPics is een uitdagende en leuke mini-game waarbij spelers vier afbeeldingen te zien krijgen die op een of andere manier met elkaar verbonden zijn. 

Het doel van het spel is om het gemeenschappelijke woord of concept te raden dat de vier afbeeldingen met elkaar delen. 

Elke afbeelding vertegenwoordigt een aspect van dit woord, maar de uitdaging is om de link te leggen tussen de verschillende beelden. Bijvoorbeeld, je zou vier afbeeldingen kunnen zien van een hond, een kattenmand, een muis en een vogelkooi. Het gemeenschappelijke woord in dit geval zou "huisdier" zijn, omdat al deze dingen verband houden met dieren die vaak als huisdier worden gehouden. 

De game is ontworpen om zowel je visuele als je cognitieve vaardigheden te testen, omdat je niet alleen moet kijken naar de afbeeldingen, maar ook snel verbanden moet leggen. Hoe verder je komt, hoe moeilijker de combinaties van afbeeldingen zullen worden, wat het spel steeds uitdagender maakt. Elke keer dat je een correct antwoord raadt, ga je naar het volgende level, je krijgt telkens ook een hint, maar pas op hier worden punten voor afgetrokken, wat betekent dat je steeds meer op je eigen creativiteit en kennis moet vertrouwen. BrainPics is dus een perfecte game voor iedereen die van breinbrekers en puzzels houdt!



Figma link: https://www.figma.com/design/aLACuleK9bM4UBR7q3Swxv/Untitled?node-id=0-1&t=tEQRV0kaHe4ufh6Q-1 