class BrainPics {
    constructor() {
        this.currentLevel = 5;
        this.score = 380;
        this.answer = 'MONEY';
        this.currentGuess = '';
        this.initializeGame();
    }

    initializeGame() {
        this.setupLetterChoices();
        this.setupOptions();
        this.updateScore();
    }

    setupLetterChoices() {
        const letterButtons = document.querySelectorAll('.letter');
        letterButtons.forEach(button => {
            button.addEventListener('click', () => this.handleLetterClick(button));
        });
    }

    setupOptions() {
        const hintButton = document.querySelector('.hint-button');

        hintButton.addEventListener('click', () => this.showHint());
    }

    handleLetterClick(button) {
        if (this.currentGuess.length < this.answer.length) {
            const letter = button.textContent;
            this.currentGuess += letter;
            this.updateSlots();
            button.disabled = true;
            button.classList.add('selected');

            if (this.currentGuess.length === this.answer.length) {
                this.checkAnswer();
            }
        }
    }

    updateSlots() {
        const slots = document.querySelectorAll('.slot');
        slots.forEach((slot, index) => {
            slot.textContent = this.currentGuess[index] || '';
        });
    }

    checkAnswer() {
        if (this.currentGuess === this.answer) {
            alert('Correct! Congratulations, you have reached the final level! Well done!');
            this.score += 100;
            this.updateScore();
        } else {
            alert('Wrong answer! Try again.');
            this.resetGuess();
        }
    }

    resetGuess() {
        this.currentGuess = '';
        this.updateSlots();
        const letterButtons = document.querySelectorAll('.letter');
        letterButtons.forEach(button => {
            button.disabled = false;
            button.classList.remove('selected');
        });
    }

    showHint() {
        alert('Hint: Everybody wants it.');
        this.score -= 10;
        this.updateScore();
    }


    updateScore() {
        const scoreElement = document.querySelector('.score');
        scoreElement.textContent = `${this.score} pts`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new BrainPics();
});