class BrainPics {
    constructor() {
        this.currentLevel = 1;
        this.score = 0;
        this.answer = 'TIME';
        this.currentGuess = '';
        this.initializeGame();
    }

    initializeGame() {
        this.setupLetterChoices();
        this.setupOptions();
        this.updateScore();
    }

    setupLetterChoices() {
        const letterButtons = document.querySelectorAll('.letter');
        letterButtons.forEach(button => {
            button.addEventListener('click', () => this.handleLetterClick(button));
        });
    }

    setupOptions() {
        const hintButton = document.querySelector('.hint-button');
        const nextButton = document.querySelector('.next-button');

        hintButton.addEventListener('click', () => this.showHint());
        nextButton.addEventListener('click', () => this.nextLevel());
    }

    handleLetterClick(button) {
        if (this.currentGuess.length < this.answer.length) {
            const letter = button.textContent;
            this.currentGuess += letter;
            this.updateSlots();
            button.disabled = true;
            button.classList.add('selected');

            if (this.currentGuess.length === this.answer.length) {
                this.checkAnswer();
            }
        }
    }

    updateSlots() {
        const slots = document.querySelectorAll('.slot');
        slots.forEach((slot, index) => {
            slot.textContent = this.currentGuess[index] || '';
        });
    }

    checkAnswer() {
        if (this.currentGuess === this.answer) {
            alert('Correct! Click NEXT to continue.');
            this.score += 100;
            this.updateScore();
        } else {
            alert('Wrong answer! Try again.');
            this.resetGuess();
        }
    }

    resetGuess() {
        this.currentGuess = '';
        this.updateSlots();
        const letterButtons = document.querySelectorAll('.letter');
        letterButtons.forEach(button => {
            button.disabled = false;
            button.classList.remove('selected');
        });
    }

    showHint() {
        alert('Hint: It is something we measure with hours, minutes and seconds.');
        this.score -= 10;
        this.updateScore();
    }

    updateScore() {
        const scoreElement = document.querySelector('.score');
        scoreElement.textContent = `${this.score} pts`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new BrainPics();
});